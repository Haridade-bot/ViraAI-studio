 "use client";

import { ChangeEvent, FormEvent, useEffect, useState } from "react";

type Mode = "fashion" | "product";
type UploadField = "person" | "item";

export default function Home() {
  const [mode, setMode] = useState<Mode>("fashion");
  const [person, setPerson] = useState<File | null>(null);
  const [item, setItem] = useState<File | null>(null);
  const [personPreview, setPersonPreview] = useState("");
  const [itemPreview, setItemPreview] = useState("");
  const [duration, setDuration] = useState("5");
  const [style, setStyle] = useState("realistic commercial");
  const [prompt, setPrompt] = useState("Vídeo publicitário realista, iluminação profissional, movimentos naturais de câmera, mostrar os detalhes do produto, sem texto deformado.");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [resultImage, setResultImage] = useState("");

  useEffect(() => {
    return () => {
      if (personPreview) URL.revokeObjectURL(personPreview);
      if (itemPreview) URL.revokeObjectURL(itemPreview);
    };
  }, [personPreview, itemPreview]);

  function selectFile(field: UploadField, e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Envie uma imagem JPG, PNG ou WEBP.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Cada imagem deve ter no máximo 10 MB.");
      return;
    }
    setError("");
    if (field === "person") {
      setPerson(file);
      setPersonPreview(URL.createObjectURL(file));
    } else {
      setItem(file);
      setItemPreview(URL.createObjectURL(file));
    }
    setVideoUrl("");
    setResultImage("");
  }

  async function generate(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setVideoUrl("");
    setResultImage("");
    if (!item) {
      setError(mode === "fashion" ? "Envie a foto da roupa." : "Envie a foto do produto.");
      return;
    }
    if (mode === "fashion" && !person) {
      setError("Envie também a foto da modelo.");
      return;
    }

    const body = new FormData();
    body.append("mode", mode);
    body.append("duration", duration);
    body.append("style", style);
    body.append("prompt", prompt);
    if (person) body.append("person", person);
    body.append("item", item);

    setLoading(true);
    setStatus(mode === "fashion" ? "Etapa 1/2: preparando o provador virtual…" : "Preparando o produto para o vídeo…");
    try {
      const response = await fetch("/api/generate", { method: "POST", body });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Não foi possível gerar o vídeo.");
      if (data.resultImage) setResultImage(data.resultImage);
      setStatus("Vídeo pronto!");
      setVideoUrl(data.videoUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado. Tente novamente.");
      setStatus("");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-icon">▶</span><span>Vira<span>AI</span><small>STUDIO DE ANÚNCIOS</small></span></a>
        <a className="top-link" href="#como-funciona">Como funciona</a>
        <span className="pill">IA • VÍDEOS ATÉ 30s</span>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="spark">✦</span> SEU ESTÚDIO DE PUBLICIDADE COM IA</div>
          <h1>Transforme fotos em <span>anúncios que chamam atenção.</span></h1>
          <p>Envie a foto de uma modelo e uma roupa, ou apenas um produto. A IA prepara a imagem e cria um vídeo publicitário realista para suas redes sociais.</p>
          <a className="primary-link" href="#criar">Criar meu primeiro vídeo <span>↘</span></a>
          <div className="trust-row"><span>✓ Funciona no celular</span><span>✓ Download MP4</span><span>✓ 3–30 segundos</span></div>
        </div>
        <div className="hero-art">
          <div className="preview-window">
            <div className="preview-top"><span className="dot"></span><span>PRÉVIA DO ESTÚDIO</span><span className="live">IA</span></div>
            <div className="preview-body">
              <div className="mini-stack"><div className="mini-image model-mini">MODELO</div><div className="plus">＋</div><div className="mini-image item-mini">PRODUTO</div></div>
              <div className="mock-video"><div className="mock-glow"></div><div className="play">▶</div><div className="mock-caption">Sua próxima<br/>campanha começa aqui.</div><div className="mock-timeline"><i></i></div></div>
            </div>
            <div className="preview-bottom"><span>● IMAGINAÇÃO</span><span>● CRIAÇÃO</span><span>● PUBLICAÇÃO</span></div>
          </div>
          <div className="floating-note"><span>✦</span><div><b>Criação inteligente</b><small>Do upload ao vídeo final</small></div></div>
        </div>
      </section>

      <section className="how" id="como-funciona">
        <div className="section-heading"><div><div className="eyebrow">SIMPLES ASSIM</div><h2>Três passos. Um anúncio pronto.</h2></div><p>Você controla o conceito. A IA faz o trabalho pesado.</p></div>
        <div className="steps">
          <article><div className="step-number">01</div><h3>Envie as imagens</h3><p>Foto da modelo e da roupa, ou uma imagem do produto que quer divulgar.</p></article>
          <article><div className="step-number">02</div><h3>Descreva a ideia</h3><p>Escolha a duração, o estilo e o que o vídeo deve destacar.</p></article>
          <article><div className="step-number">03</div><h3>Gere e baixe</h3><p>Veja o resultado e baixe o MP4 para publicar nas suas redes.</p></article>
        </div>
      </section>

      <section className="creator-section" id="criar">
        <div className="creator-heading"><div className="eyebrow">VIRAAI CREATOR</div><h2>Vamos criar seu anúncio</h2><p>Use imagens que você tem autorização para utilizar.</p></div>
        <form className="creator" onSubmit={generate}>
          <div className="form-panel">
            <div className="mode-switch" role="tablist" aria-label="Tipo de anúncio">
              <button type="button" className={mode === "fashion" ? "mode active" : "mode"} onClick={() => {setMode("fashion"); setVideoUrl(""); setError("");}}><span>♙</span> Moda / provador</button>
              <button type="button" className={mode === "product" ? "mode active" : "mode"} onClick={() => {setMode("product"); setVideoUrl(""); setError("");}}><span>◇</span> Anúncio de produto</button>
            </div>

            <div className="upload-grid">
              {mode === "fashion" && <label className="upload-card">
                <input type="file" accept="image/*" onChange={(e) => selectFile("person", e)} />
                {personPreview ? <img className="upload-preview" src={personPreview} alt="Prévia da modelo" /> : <span className="upload-symbol">♙</span>}
                <b>1. Foto da modelo</b><small>{person ? person.name : "Toque para escolher uma imagem"}</small><em>{person ? "Trocar imagem" : "+ Adicionar foto"}</em>
              </label>}
              <label className="upload-card">
                <input type="file" accept="image/*" onChange={(e) => selectFile("item", e)} />
                {itemPreview ? <img className="upload-preview" src={itemPreview} alt="Prévia do produto ou roupa" /> : <span className="upload-symbol">◇</span>}
                <b>{mode === "fashion" ? "2. Foto da roupa" : "Foto do produto"}</b><small>{item ? item.name : "De preferência, fundo limpo"}</small><em>{item ? "Trocar imagem" : "+ Adicionar foto"}</em>
              </label>
            </div>

            <label className="field-label" htmlFor="duration">Duração do vídeo <strong>{duration} segundos</strong></label>
            <input id="duration" className="range" type="range" min="3" max="30" step="1" value={duration} onChange={(e) => setDuration(e.target.value)} />
            <div className="range-labels"><span>3s</span><span>15s</span><span>30s</span></div>

            <label className="field-label" htmlFor="style">Estilo visual</label>
            <select id="style" value={style} onChange={(e) => setStyle(e.target.value)}>
              <option value="realistic commercial">Publicidade realista</option>
              <option value="cinematic luxury commercial">Cinematográfico / luxo</option>
              <option value="bright social media ad">Claro e vibrante para redes sociais</option>
              <option value="minimal studio product commercial">Estúdio minimalista</option>
            </select>

            <label className="field-label" htmlFor="prompt">O que deve acontecer no anúncio?</label>
            <textarea id="prompt" rows={3} value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={700} placeholder="Ex.: mostrar os detalhes, movimentos naturais e uma cena elegante…" />

            {error && <div className="error" role="alert">{error}</div>}
            {status && <div className="status" role="status">{loading && <span className="spinner"></span>}{status}</div>}
            <button className="generate-button" type="submit" disabled={loading}>
              {loading ? <><span className="spinner"></span> Criando seu anúncio…</> : <>✦ Gerar vídeo com IA <span>→</span></>}
            </button>
            <p className="fine-print">A geração usa serviços de IA externos e pode ter custo por uso. A chave da API fica protegida no servidor.</p>
          </div>

          <div className="result-panel">
            <div className="result-top"><div><span className="eyebrow">RESULTADO</span><h3>Sua prévia aparecerá aqui</h3></div><span className="format-tag">MP4 • VERTICAL</span></div>
            {videoUrl ? <div className="video-result">
              <video controls playsInline src={videoUrl} poster={resultImage || undefined} />
              <a className="download-button" href={videoUrl} target="_blank" rel="noreferrer" download="virai-anuncio.mp4">↓ Baixar vídeo MP4</a>
              <p>Se o download não começar, abra o vídeo e use o menu do navegador para baixar.</p>
            </div> : <div className="empty-result">
              {resultImage ? <img src={resultImage} alt="Imagem preparada para o anúncio" /> : <div className="empty-art"><div className="empty-orbit orbit-one"></div><div className="empty-orbit orbit-two"></div><div className="empty-play">▶</div><span className="sparkle s1">✦</span><span className="sparkle s2">✧</span></div>}
              <b>{loading ? "A IA está trabalhando…" : "Seu próximo anúncio começa com uma imagem"}</b>
              <p>{loading ? "Pode levar alguns minutos. Não feche esta página." : "Envie suas imagens e toque em “Gerar vídeo com IA” para começar."}</p>
            </div>}
            <div className="result-checks"><div><span>✦</span><div><b>Imagem para vídeo</b><small>Movimento gerado por IA</small></div></div><div><span>↗</span><div><b>Pronto para redes sociais</b><small>Ideal para Reels, TikTok e Shorts</small></div></div><div><span>↓</span><div><b>Arquivo para baixar</b><small>MP4 hospedado pelo provedor</small></div></div></div>
          </div>
        </form>
      </section>

      <footer><a className="brand" href="#"><span className="brand-icon">▶</span><span>Vira<span>AI</span><small>STUDIO DE ANÚNCIOS</small></span></a><p>Protótipo independente. Revise os direitos das imagens, músicas e marcas antes de publicar.</p></footer>
    </main>
  );
}