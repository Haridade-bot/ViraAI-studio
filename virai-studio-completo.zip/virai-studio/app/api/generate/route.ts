import { fal } from "@fal-ai/client";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 300;

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const TRY_ON_MODEL = "fal-ai/image-apps-v2/virtual-try-on";
const VIDEO_MODEL = "kling/v4/image-to-video";

function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export async function POST(request: Request) {
  try {
    const apiKey = process.env.FAL_KEY;
    if (!apiKey) {
      return jsonError("A chave FAL_KEY não está configurada. Copie .env.example para .env.local e adicione sua chave da fal.ai.", 500);
    }
    fal.config({ credentials: apiKey });

    const form = await request.formData();
    const mode = String(form.get("mode") || "fashion");
    const duration = Number(form.get("duration") || 5);
    const style = String(form.get("style") || "realistic commercial");
    const userPrompt = String(form.get("prompt") || "").slice(0, 700);
    const person = form.get("person");
    const item = form.get("item");

    if (mode !== "fashion" && mode !== "product") return jsonError("Tipo de anúncio inválido.");
    if (!Number.isInteger(duration) || duration < 3 || duration > 30) return jsonError("A duração deve ser entre 3 e 30 segundos.");
    if (!(item instanceof File)) return jsonError("Envie a foto da roupa ou do produto.");
    if (item.size > MAX_FILE_SIZE) return jsonError("A imagem do produto excede 10 MB.");
    if (!item.type.startsWith("image/")) return jsonError("O arquivo do produto precisa ser uma imagem.");

    let startImageUrl: string;
    let resultImage: string | undefined;

    if (mode === "fashion") {
      if (!(person instanceof File)) return jsonError("Envie a foto da modelo.");
      if (person.size > MAX_FILE_SIZE) return jsonError("A imagem da modelo excede 10 MB.");
      if (!person.type.startsWith("image/")) return jsonError("A foto da modelo precisa ser uma imagem.");

      const [personUrl, clothingUrl] = await Promise.all([
        fal.storage.upload(person),
        fal.storage.upload(item),
      ]);

      const tryOnResult: any = await fal.subscribe(TRY_ON_MODEL, {
        input: {
          person_image_url: personUrl,
          clothing_image_url: clothingUrl,
          preserve_pose: true,
          aspect_ratio: "9:16",
        },
        logs: false,
      });
      startImageUrl = tryOnResult?.data?.images?.[0]?.url;
      if (!startImageUrl) throw new Error("A IA de provador virtual não retornou uma imagem.");
      resultImage = startImageUrl;
    } else {
      startImageUrl = await fal.storage.upload(item);
    }

    const productPrompt = mode === "fashion"
      ? "Create a photorealistic fashion advertisement video using the provided image as the exact first frame. Keep the same person's face, identity, outfit, fabric, colors and body proportions consistent. Natural subtle body movement, realistic fabric motion, elegant camera movement, commercial lighting. Do not change the garment design."
      : "Create a photorealistic product advertisement video using the provided image as the exact first frame. Preserve the product's exact shape, branding, colors and details. Premium product cinematography, smooth controlled camera movement, realistic reflections and lighting. Do not invent extra labels or distort the product.";

    const prompt = [productPrompt, `Visual style: ${style}.`, userPrompt].filter(Boolean).join(" ");

    const videoResult: any = await fal.subscribe(VIDEO_MODEL, {
      input: {
        prompt,
        start_image_url: startImageUrl,
        duration,
        resolution: "720p",
      },
      logs: false,
    });

    const videoUrl = videoResult?.data?.video?.url;
    if (!videoUrl) throw new Error("O serviço de vídeo não retornou um arquivo. Tente novamente.");
    return NextResponse.json({ videoUrl, resultImage, duration });
  } catch (error) {
    console.error("ViraAI generation error:", error);
    const message = error instanceof Error ? error.message : "Erro inesperado durante a geração.";
    return jsonError(
      message.includes("401") || message.toLowerCase().includes("unauthorized")
        ? "A chave da fal.ai parece inválida. Confira FAL_KEY em .env.local."
        : `Não foi possível gerar o anúncio. ${message}`,
      500,
    );
  }
}