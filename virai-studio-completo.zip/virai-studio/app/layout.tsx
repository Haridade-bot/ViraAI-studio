import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ViraAI Studio — Anúncios com IA",
  description: "Crie vídeos de anúncios com IA a partir de fotos de modelos, roupas e produtos.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}