# ViraAI Studio — gerador de anúncios por IA

Aplicação web responsiva em Next.js para:
- receber foto de uma pessoa e foto de uma roupa;
- usar um modelo de provador virtual para compor a roupa na pessoa;
- criar um vídeo a partir da imagem final;
- ou criar um vídeo publicitário diretamente de uma foto de produto;
- visualizar e abrir/baixar o vídeo MP4.

## Importante sobre custos

O código é gratuito e pode ser executado localmente. A geração de imagens/vídeos é feita por APIs externas da fal.ai e pode cobrar por geração. Consulte os preços atuais antes de testar. Não existe promessa de geração ilimitada gratuita.

Modelos usados:
- Provador virtual: `fal-ai/image-apps-v2/virtual-try-on`
- Imagem para vídeo: `kling/v4/image-to-video`

## Requisitos

- Node.js 20.9 ou mais recente (recomendado)
- Conta na fal.ai e chave API
- Internet para instalar dependências e chamar os modelos

## Executar no computador

1. Extraia o ZIP.
2. Abra um terminal dentro da pasta `virai-studio`.
3. Instale as dependências:

   ```bash
   npm install
   ```

4. Copie `.env.example` para `.env.local`.
5. Abra `.env.local` e substitua `put_your_fal_api_key_here` pela sua chave criada em https://fal.ai/dashboard/keys.
6. Rode:

   ```bash
   npm run dev
   ```

7. Acesse http://localhost:3000.

Nunca coloque `FAL_KEY` no código do navegador nem compartilhe `.env.local`.

## Executar pelo celular

A maneira mais simples é usar um computador para configurar o projeto e depois publicar em um serviço que suporte Next.js, como Vercel. Configure `FAL_KEY` nas variáveis de ambiente do projeto publicado. Depois abra o endereço do site no celular.

Também é possível editar o projeto em um ambiente de desenvolvimento online compatível com Next.js, mas a chave deve continuar como variável de ambiente do servidor.

## Como usar

1. Escolha **Moda / provador** para enviar a foto da modelo e a foto da roupa. Ou escolha **Anúncio de produto** e envie só a foto do produto.
2. Selecione a duração (3 a 30 segundos), estilo e descreva o movimento.
3. Clique em **Gerar vídeo com IA** e aguarde.
4. Quando terminar, reproduza a prévia e abra/baixe o MP4.

## Limitações e melhorias recomendadas antes de lançar publicamente

- O primeiro protótipo envia imagens para o provedor de IA. Use apenas imagens que você tenha direito de usar e informe isso aos usuários.
- O resultado pode alterar detalhes da roupa/produto; revise antes de publicar.
- O link de vídeo retornado é hospedado pelo provedor. Para produção, copie o arquivo para armazenamento próprio e implemente autenticação, quotas, rate limiting, monitoramento e exclusão automática.
- O endpoint aguarda a geração durante a requisição; para grande volume, troque por tarefas em fila e polling/webhooks.
- A duração final depende do modelo de vídeo e dos limites atuais do provedor. Se uma duração específica não for suportada pela conta/modelo, escolha outra duração.
- O site não adiciona automaticamente música, legendas animadas, preço ou CTA dentro do vídeo. Essas funcionalidades podem ser implementadas em uma etapa posterior.
- Para uso comercial, confira os termos e a licença dos modelos e serviços que você escolher.

## Arquitetura

`app/page.tsx` — interface e upload  
`app/api/generate/route.ts` — endpoint de servidor que envia arquivos e chama os modelos  
`app/globals.css` — estilo responsivo  
`.env.example` — exemplo da variável de ambiente
